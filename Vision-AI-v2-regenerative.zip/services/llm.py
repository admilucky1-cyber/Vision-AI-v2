"""
Vision AI v2.0 - AI Provider Router
====================================
Multi-provider LLM integration with intelligent failover and dynamic prompt assembly.

Architecture:
- routes/chat.py owns routing (files, YouTube, web search, greetings).
- This module ONLY calls language models with the context it is given.
- Search inside ask_ai is a last-resort safety net when context is empty
  and the question clearly needs live data.
"""

from __future__ import annotations

import os
import re
import time
import logging
from typing import Optional, Dict, List, Any, Callable

import requests
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("vision-ai.llm")

# ==========================================================
# PROVIDER CONFIGURATION
# ==========================================================
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GEMINI_AVAILABLE = False
gemini_client = None

try:
    import google.genai as genai

    if GOOGLE_API_KEY:
        gemini_client = genai.Client(api_key=GOOGLE_API_KEY)
        GEMINI_AVAILABLE = True
        logger.info("✅ Gemini API initialized successfully")
    else:
        logger.warning("⚠️ GOOGLE_API_KEY not set in .env")
except ImportError as e:
    logger.warning(f"⚠️ google-genai not installed: {e}")
    GEMINI_AVAILABLE = False

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_AVAILABLE = bool(DEEPSEEK_API_KEY)

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_AVAILABLE = bool(GROQ_API_KEY)

OPENROUTER_KEY = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_AVAILABLE = bool(OPENROUTER_KEY)

# ==========================================================
# MODELS
# ==========================================================
GEMINI_MODELS: Dict[str, Dict[str, Any]] = {
    # Prefer 2.5 family when available; keep 1.5 as compatibility fallback
    "gemini-2.5-flash": {"name": "Gemini 2.5 Flash", "tokens": 1_048_576, "priority": 1},
    "gemini-2.5-pro": {"name": "Gemini 2.5 Pro", "tokens": 1_048_576, "priority": 2},
    "gemini-2.0-flash": {"name": "Gemini 2.0 Flash", "tokens": 1_048_576, "priority": 3},
    "gemini-1.5-flash": {"name": "Gemini 1.5 Flash", "tokens": 2_000_000, "priority": 4},
    "gemini-1.5-pro": {"name": "Gemini 1.5 Pro", "tokens": 2_000_000, "priority": 5},
}

OPENROUTER_MODELS: List[Dict[str, Any]] = [
    # Prefer :free models (rotate on OpenRouter; check openrouter.ai/models?q=free)
    {"id": "openrouter/free", "name": "OpenRouter Free Router", "tokens": 128_000},
    {"id": "meta-llama/llama-3.3-70b-instruct:free", "name": "Llama 3.3 70B (free)", "tokens": 131_072},
    {"id": "nvidia/nemotron-3-super-120b-a12b:free", "name": "Nemotron 3 Super (free)", "tokens": 262_144},
    {"id": "google/gemma-2-9b-it:free", "name": "Gemma 2 9B (free)", "tokens": 8192},
    {"id": "qwen/qwen-2.5-72b-instruct:free", "name": "Qwen 2.5 72B (free)", "tokens": 131_072},
]

# ==========================================================
# PROMPTS
# ==========================================================
MASTER_SYSTEM_PROMPT = """You are VISION AI, an advanced, warm, and natural conversational AI assistant — sharp, practical, and never boring.

MISSION:
Maximize the user's long-term success with accurate, well-reasoned, practical, and transparent assistance.

PRIMARY OBJECTIVES:
• Respond like a skilled human expert who actually cares about the answer.
• Optimize for clarity, warmth, and truth — avoid filler and generic lectures.
• Prefer concrete examples, short structure, and direct answers.
• When answering a factual question, give a clear, direct answer first, then brief support.
• If the question is ambiguous, give the most likely interpretation answer, then one clarifying question.

IMAGE REQUESTS (CRITICAL):
• When the user asks to create / generate / draw an image (e.g. "create a falcon image"), the server generates a real image separately.
• Do NOT output large ASCII art as a substitute. Give a short, natural caption only (1–3 sentences).
• Never pretend you cannot generate images if the user asked for one — the pipeline handles visuals.

COMMUNICATION:
- Use contractions (don't, can't, I'll) when writing English.
- Use "I", "you", and "we" naturally.
- Do not start with formalities like "Here is a breakdown..." or "In summary...".
- Start directly with the answer. Avoid robotic, repetitive openings.

LANGUAGE MATCHING (CRITICAL):
• Always reply in the same language the user is writing in.
• Roman Urdu / Pakistani informal (e.g. "kon h", "batao", "kya hai", "krna") → reply in clear Pakistani Urdu (Urdu script preferred; if Roman, use Pakistani style, NOT Hindi).
• If the user asks for "Pakistani Urdu", "Urdu", "اردو" → answer in Urdu (Nastaliq/Arabic script).
• If the user asks for Arabic → use Arabic script.
• Never answer a Pakistani Urdu question in Hindi (Devanagari or Hindi vocabulary like "bhagwan", "ishwar", "dharm", "sarvashaktimaan") unless they asked for Hindi.
• For Islamic / religious questions: be respectful, accurate to mainstream Islamic teachings when an Islamic view is requested; avoid mixing Hindu theological terms into Islamic answers.

SYNTHESIS (CRITICAL):
When context contains [WEB SEARCH RESULTS], [REAL-TIME LIVE DATA FROM WEB],
[DEDICATED WEB SEARCH RESULTS], [Uploaded File], or [YouTube Metadata]:
• Synthesize the facts into one coherent, friendly answer.
• Do NOT dump raw bullet lists of search hits or cite "Source: duckduckgo".
• Do NOT say "based on the search results" unless the user asks for sources.
• Prefer the most recent and authoritative facts when they conflict.

SELF-REVIEW:
Before finalizing, check logic, factual consistency, and completeness.

When the user message context includes [IMAGE: ...], [PDF Content], OCR text, or uploaded document blocks, you MUST use that content. Never claim you cannot see or read the file if that context is present. If OCR text is partial, answer from what is available and note uncertainty.\nFor multiple-choice physics papers: reason carefully; alpha particles (not beta) are stopped by paper; check units and diagram labels. Do not invent option letters not in the paper. Never repeat a previous paper's answers when a new document is provided."""

EXPERT_PROMPTS: Dict[str, str] = {
    "general": MASTER_SYSTEM_PROMPT,
    "coding": (
        "You are a senior software architect. Produce production-ready code. "
        "Follow SOLID principles. Optimize for readability. Include error handling. "
        "Explain important design decisions."
    ),
    "debugging": (
        "Act as a senior debugging engineer. Identify root cause. Do not guess. "
        "Explain why it happens. Provide corrected code and why the fix works."
    ),
    "security": (
        "Act as a penetration tester. Review for SQLi, XSS, CSRF, auth flaws, SSRF, RCE. "
        "Output: Severity, Risk, Mitigation."
    ),
    "research": (
        "Behave like a PhD researcher. Provide evidence, reasoning, alternative viewpoints, "
        "and separate facts from opinions."
    ),
    "math": (
        "Solve problems rigorously. Show definitions, formula derivation, final answer, "
        "and verification."
    ),
    "teaching": (
        "Adapt explanations to the user's level. Use analogies, examples, practice questions, "
        "and common mistakes."
    ),
}

SUBJECT_KEYWORDS: Dict[str, List[str]] = {
    "english": ["english", "grammar", "writing", "reading", "sentence", "verb", "tense", "noun", "adjective", "adverb", "preposition"],
    "physics": ["physics", "force", "velocity", "acceleration", "magnetic", "electric", "circuit", "wave", "energy", "momentum", "gravity", "newton", "ohm", "voltage", "refraction", "quantum", "speed", "motion", "mass", "friction", "pressure", "density", "frequency", "wavelength"],
    "chemistry": ["chemistry", "reaction", "molecule", "atom", "element", "compound", "acid", "base", "organic", "periodic", "bond", "ion"],
    "biology": ["biology", "cell", "dna", "protein", "gene", "organism", "photosynthesis", "respiration", "enzyme", "mitosis", "meiosis", "evolution", "ecology", "anatomy", "physiology", "species", "bacteria", "virus", "plant", "animal"],
    "mathematics": ["math", "algebra", "calculus", "geometry", "trigonometry", "equation", "function", "derivative", "integral", "matrix", "vector", "probability", "statistics", "theorem", "angle", "triangle", "circle", "graph", "coordinate", "polynomial"],
    "engineering": ["engineering", "mechanical", "civil", "electrical", "structural", "design", "manufacturing", "circuit", "signal", "control system", "motor", "generator", "transformer", "load", "stress"],
    "computer_science": ["programming", "algorithm", "code", "software", "hardware", "database", "network", "ai", "machine learning", "python", "java", "c++", "web", "app", "function", "class", "object", "api", "server", "client"],
    "medicine": ["medicine", "diagnosis", "treatment", "symptom", "disease", "surgery", "pharma", "clinical", "patient", "anatomy", "pathology", "radiology"],
    "history": ["history", "ancient", "medieval", "modern", "war", "revolution", "empire", "civilization", "century", "timeline", "historical", "king", "queen", "dynasty", "battle", "treaty"],
    "geography": ["geography", "climate", "weather", "map", "continent", "ocean", "river", "mountain", "population", "urban", "rural", "country", "capital", "latitude", "longitude", "equator"],
    "economics": ["economics", "supply", "demand", "market", "inflation", "gdp", "finance", "investment", "trade", "monetary", "fiscal", "business", "cost", "revenue", "profit"],
}

# ==========================================================
# UTILITY HELPERS
# ==========================================================
_GREETING_RE = re.compile(
    r"^(hi|hello|hey|howdy|good\s+(morning|afternoon|evening))([!.\s]*)$",
    re.IGNORECASE,
)

_FILE_COMMANDS = ("solve", "summarize", "analyse", "analyze", "translate", "extract", "explain", "answer", "read")

_UNCERTAIN_TRIGGERS = (
    "latest", "current", "today", "now", "recent", "breaking", "weather",
    "stock", "price", "score", "result", "news", "forecast",
    "2024", "2025", "2026", "2027", "2028", "2029", "2030",
)

_VAGUE_RESPONSE_TRIGGERS = (
    "i'm not sure", "i don't know", "i think", "maybe", "perhaps",
    "could be", "might be", "possibly", "it depends", "not sure",
    "i'm not entirely sure", "i can't say for sure",
)


def is_greeting(question: str) -> bool:
    """Exact greeting only — never match substrings like 'highlight'."""
    return _GREETING_RE.fullmatch(question.strip()) is not None


def is_ambiguous(question: str) -> bool:
    """
    True only for truly underspecified prompts (single vague pronouns).
    Short factual questions must NOT be treated as ambiguous.
    """
    q = question.strip().lower()
    if not q or is_greeting(q):
        return False
    if q.endswith("?"):
        return False
    if any(q.startswith(cmd) for cmd in _FILE_COMMANDS):
        return False
    if len(q.split()) >= 3:
        return False
    vague_only = {"this", "that", "it", "these", "those", "help", "ok", "yes", "no"}
    return q in vague_only


def is_uncertain(question: str) -> bool:
    """Questions that benefit from live / current information."""
    q = question.lower()
    return any(t in q for t in _UNCERTAIN_TRIGGERS)


def is_vague(response: str) -> bool:
    if not response:
        return True
    r = response.lower()
    return any(t in r for t in _VAGUE_RESPONSE_TRIGGERS)


def detect_subject(question: str, context: str = "", filename: str = "") -> str:
    if filename:
        fl = filename.lower()
        for subject, keywords in SUBJECT_KEYWORDS.items():
            if any(kw in fl for kw in keywords):
                return subject
    combined = (question + " " + (context or "")[:5000]).lower()
    scores: Dict[str, int] = {}
    for subject, keywords in SUBJECT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in combined)
        if score > 0:
            scores[subject] = score
    return max(scores, key=scores.get) if scores else "general"


def detect_intent(question: str) -> str:
    q_lower = question.lower()
    domain_map = {
        "coding": ["code", "python", "javascript", "react", "api", "fastapi", "docker", "git", "sql", "function", "app"],
        "debugging": ["error", "bug", "exception", "traceback", "stack", "crash", "not working", "issue", "fail"],
        "security": ["security", "vulnerability", "hack", "exploit", "penetration", "xss", "sql injection", "csrf"],
        "math": ["math", "equation", "calculate", "solve", "derivative", "integral", "matrix", "vector", "probability"],
        "research": ["research", "paper", "study", "findings", "evidence", "journal", "peer", "citation"],
        "teaching": ["explain", "teach", "tutorial", "learn", "beginner", "understand", "simple", "introduce"],
        "writing": ["write", "essay", "grammar", "rewrite", "improve", "proofread", "letter", "email"],
        "data_science": ["data", "statistics", "analyze", "trend", "insight", "visualize", "chart", "graph", "anomaly"],
        "business": ["business", "market", "strategy", "revenue", "cost", "invest", "competition", "sales"],
        "medical": ["medical", "health", "symptom", "doctor", "diagnose", "treatment", "disease", "pain"],
        "legal": ["legal", "law", "contract", "rights", "jurisdiction", "compliance", "agreement"],
    }
    scores: Dict[str, int] = {}
    for domain, keywords in domain_map.items():
        score = sum(1 for kw in keywords if kw in q_lower)
        if score > 0:
            scores[domain] = score
    return max(scores, key=scores.get) if scores else "general"


def assemble_dynamic_prompt(question: str, context: str) -> str:
    domain = detect_intent(question)
    system_prompt = MASTER_SYSTEM_PROMPT
    expert = EXPERT_PROMPTS.get(domain)
    if expert and domain != "general":
        system_prompt += f"\n\n--- DOMAIN EXPERTISE: {domain.upper()} ---\n{expert}"
    subject = detect_subject(question, context)
    if subject != "general":
        system_prompt += f"\n\nYou are answering a question related to the subject: {subject}."

    ctx = context or ""
    q = (question or "").lower()

    # Document-aware instructions (exam PDFs, mark schemes, etc.)
    if "[MARK SCHEME" in ctx or "MARK SCHEME / ANSWER KEY" in ctx:
        system_prompt += """

--- DOCUMENT MODE: MARK SCHEME ---
The context contains an official mark scheme (answer key), not unanswered questions.
• If the user says "solve", teach: for each item explain WHY the keyed answer is correct.
• Use clear physics reasoning (definitions, formulas, units, common traps).
• Do not invent alternate answers that contradict the mark scheme.
• Do not recommend external "AI PDF solver" websites.
• Structure: Question number → Correct option → Short explanation."""
    elif "[QUESTION PAPER" in ctx:
        system_prompt += """

--- DOCUMENT MODE: QUESTION PAPER ---
The context contains exam questions the user wants solved.
• Work systematically. For multiple-choice: show reasoning then the answer letter.
• For numerical questions: show formula, substitution, units, final value.
• If the user asked to "solve and explain", prioritize explanation quality over speed.
• Do not invent mark-scheme letters you cannot justify from the paper itself.
• Do not recommend external solver websites unless the user asks for tools."""
    if "[YOUTUBE VIDEO]" in ctx or "[VIDEO TRANSCRIPT" in ctx:
        system_prompt += """

--- DOCUMENT MODE: YOUTUBE VIDEO ---
Context contains YouTube metadata and (when available) a full transcript.
• If the user asks to summarize: produce a structured summary from the TRANSCRIPT.
• Lead with title + 2–4 sentence overview, then key points as bullets.
• Do NOT invent content missing from the transcript/description.
• If transcript is missing, say so and summarize from title/description only.
• Do NOT give generic advice about how to summarize — do the summary.
• If the user asks to download the video/audio, tell them the app handles downloads natively
  (use the Download intent) — do NOT recommend third-party downloader websites."""

    elif "[UPLOADED DOCUMENT" in ctx or "[Uploaded File" in ctx:
        system_prompt += """

--- DOCUMENT MODE ---
Use the uploaded document as the primary source. Quote or paraphrase relevant parts.
Answer the user's request directly (solve / summarize / explain / extract).
Do not pad the answer with unrelated web-tool recommendations."""


    # Subject-specific STEM teaching rules (from v2 legacy prompts)
    stem_subjects = {
        "physics", "chemistry", "biology", "mathematics", "engineering", "computer_science",
    }
    if subject in stem_subjects and not any(
        m in ctx for m in ("[MARK SCHEME", "[QUESTION PAPER", "[YOUTUBE VIDEO]", "[VIDEO TRANSCRIPT")
    ):
        system_prompt += f"""

--- SUBJECT MODE: {subject.replace('_', ' ').title()} ---
You are an expert educator in this subject.
• Show every calculation and unit where relevant
• Display equations clearly (markdown / code blocks)
• Use tables for data organization when helpful
• Include ASCII diagrams for visual concepts when useful
• Always finish with a short summarized conclusion
• Prefer step-by-step reasoning over one-line answers"""

    # Stronger teaching bias for "solve" + "explain"
    if any(w in q for w in ("solve", "explain", "work out", "show working")):
        system_prompt += """

--- TASK: SOLVE / EXPLAIN ---
Lead with the answer or result, then show structured reasoning.
Prefer depth on the hardest steps. Avoid filler and product pitches."""

    # Language / locale hints from the user message
    urdu_markers = (
        "urdu", "اردو", "pakistani urdu", "roman urdu", "batao", "btao", "kya", "kia",
        "hai", "hain", "kon", "kaun", "krna", "karna", "mujhe", "mera", "nahi", "nahin",
        "allah", "islam", "quran", "namaz", "roza",
    )
    wants_urdu = any(m in q for m in ("pakistani urdu", "urdu mein", "urdu m", "اردو", "roman urdu"))
    looks_roman_urdu = any(m in q for m in ("batao", "btao", "kon h", "kya hai", "krna", "mujhe"))
    wants_arabic = any(m in q for m in ("arabic", "arabi", "عربی", "miabic"))  # miabic ≈ arabic typo
    if wants_urdu or looks_roman_urdu or any(m in q for m in urdu_markers):
        system_prompt += """

--- LANGUAGE: PAKISTANI URDU ---
The user is communicating in (or requested) Pakistani Urdu.
• Reply in Pakistani Urdu. Prefer proper Urdu script (اردو).
• If you must use Roman script, use Pakistani Roman Urdu — not Hindi.
• Do NOT use Hindi-specific vocabulary (bhagwan, ishwar, dharm, sarvashaktimaan, pratham, etc.).
• For Islamic topics use standard Islamic Urdu terms (اللہ، توحید، عبادت، شرک، ...)."""
    if wants_arabic:
        system_prompt += """

--- LANGUAGE: ARABIC ---
Also provide the relevant Islamic phrasing in Arabic script where appropriate."""


    # Comprehensive study / Q&A from uploaded books
    if any(w in q for w in (
        "all questions", "question and answer", "q&a", "quiz", "cheat sheet",
        "study guide", "from the book", "from the pdf", "from this document",
        "related book", "concept clear",
    )) and any(m in ctx for m in ("[UPLOADED DOCUMENT", "[Uploaded File", "[MARK SCHEME", "DOCUMENT")):
        system_prompt += """

--- DOCUMENT STUDY MODE ---
The user wants learning material grounded ONLY in the uploaded document.
• Use only facts, definitions, and examples present in the document context.
• If generating Q&A: produce clear questions with detailed answers that teach the concept.
• Structure: Question → short direct answer → explanation with examples from the book.
• Do not invent chapters, APIs, or claims that are not supported by the provided text.
• If the context is truncated, say what sections you covered and what may be missing.
• Prefer depth and clarity over a long list of shallow items."""

    return system_prompt


def truncate_context(context: str, model_id: str, max_tokens: int = 4000) -> str:
    if not context:
        return ""
    token_limit = 4096
    if model_id in GEMINI_MODELS:
        token_limit = int(GEMINI_MODELS[model_id]["tokens"])
    # ~4 chars/token heuristic; hard-cap with max_tokens for non-Gemini backends
    char_limit = min(token_limit * 4, max_tokens * 4 if model_id not in GEMINI_MODELS else token_limit * 4)
    # Safer practical cap for API payloads
    char_limit = min(char_limit, 120_000 if model_id in GEMINI_MODELS else max_tokens * 4)
    if len(context) > char_limit:
        return context[:char_limit] + "\n...[truncated]"
    return context


# ==========================================================
# PROVIDER IMPLEMENTATIONS
# ==========================================================
def ask_gemini(question: str, context: str = "", model_id: str = "gemini-2.5-flash") -> Optional[str]:
    if not GEMINI_AVAILABLE or not GOOGLE_API_KEY:
        return None
    try:
        import google.genai as genai

        client = genai.Client(api_key=GOOGLE_API_KEY)
        system_prompt = assemble_dynamic_prompt(question, context)
        truncated = truncate_context(context, model_id, 50_000)
        prompt = (
            f"{system_prompt}\n\n"
            f"Context:\n{truncated}\n\n"
            f"User Question:\n{question}"
        )
        logger.info(f"🔄 Calling Gemini {model_id}...")
        response = client.models.generate_content(model=model_id, contents=prompt)
        text = getattr(response, "text", None)
        if text and text.strip():
            return text.strip()
        return None
    except Exception as e:
        logger.warning(f"Gemini ({model_id}) failed: {e}")
        return None


def ask_deepseek(question: str, context: str = "") -> Optional[str]:
    if not DEEPSEEK_AVAILABLE:
        return None
    try:
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json",
        }
        truncated = truncate_context(context, "deepseek", 4000)
        system_prompt = assemble_dynamic_prompt(question, context)
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Context:\n{truncated}\n\nQuestion:\n{question}"},
            ],
            "temperature": 0.7,
            "max_tokens": 8192,
        }
        resp = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=45,
        )
        if resp.status_code == 200:
            data = resp.json()
            choices = data.get("choices") or []
            if choices:
                return (choices[0].get("message") or {}).get("content", "").strip() or None
        logger.warning(f"DeepSeek HTTP {resp.status_code}: {resp.text[:200]}")
        return None
    except Exception as e:
        logger.warning(f"DeepSeek failed: {e}")
        return None


def ask_groq(question: str, context: str = "") -> Optional[str]:
    if not GROQ_AVAILABLE:
        return None
    try:
        headers = {
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json",
        }
        truncated = truncate_context(context, "groq", 4000)
        system_prompt = assemble_dynamic_prompt(question, context)
        payload = {
            "model": "llama-3.3-70b-versatile",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Context:\n{truncated}\n\nQuestion:\n{question}"},
            ],
            "temperature": 0.7,
            "max_tokens": 8192,
        }
        resp = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=30,
        )
        if resp.status_code == 200:
            data = resp.json()
            choices = data.get("choices") or []
            if choices:
                return (choices[0].get("message") or {}).get("content", "").strip() or None
        logger.warning(f"Groq HTTP {resp.status_code}: {resp.text[:200]}")
        return None
    except Exception as e:
        logger.warning(f"Groq failed: {e}")
        return None


def ask_openrouter(question: str, context: str = "") -> Optional[str]:
    if not OPENROUTER_AVAILABLE:
        return None
    headers = {
        "Authorization": f"Bearer {OPENROUTER_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://vision-ai.app",
        "X-Title": "Vision AI",
    }
    truncated = truncate_context(context, "openrouter", 4000)
    system_prompt = assemble_dynamic_prompt(question, context)
    for model_info in OPENROUTER_MODELS:
        try:
            payload = {
                "model": model_info["id"],
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Context:\n{truncated}\n\nQuestion:\n{question}"},
                ],
                "temperature": 0.7,
                "max_tokens": 8192,
            }
            resp = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers=headers,
                json=payload,
                timeout=30,
            )
            if resp.status_code == 200:
                data = resp.json()
                choices = data.get("choices") or []
                if choices:
                    content = (choices[0].get("message") or {}).get("content", "").strip()
                    if content:
                        return content
            else:
                logger.debug(f"OpenRouter {model_info['id']} HTTP {resp.status_code}")
        except Exception as e:
            logger.debug(f"OpenRouter {model_info['id']} failed: {e}")
            continue
    return None


# ==========================================================
# MAIN ROUTER
# ==========================================================
def _build_provider_chain(backend: str) -> List[tuple]:
    # Priority from old roadmap: 2.5 Flash → 2.5 Pro → DeepSeek → 2.0 Flash → Groq → OpenRouter
    g25_flash = ("gemini-2.5-flash", lambda q, c: ask_gemini(q, c, "gemini-2.5-flash"))
    g25_pro = ("gemini-2.5-pro", lambda q, c: ask_gemini(q, c, "gemini-2.5-pro"))
    g20_flash = ("gemini-2.0-flash", lambda q, c: ask_gemini(q, c, "gemini-2.0-flash"))
    g15_flash = ("gemini-1.5-flash", lambda q, c: ask_gemini(q, c, "gemini-1.5-flash"))
    g15_pro = ("gemini-1.5-pro", lambda q, c: ask_gemini(q, c, "gemini-1.5-pro"))
    deepseek = ("deepseek", ask_deepseek)
    groq = ("groq", ask_groq)
    openrouter = ("openrouter", ask_openrouter)

    if backend == "auto":
        return [g25_flash, g25_pro, deepseek, g20_flash, groq, openrouter, g15_flash, g15_pro]
    if backend == "gemini":
        return [g25_flash, g25_pro, g20_flash, g15_flash, g15_pro]
    if backend == "deepseek":
        return [deepseek]
    if backend == "groq":
        return [groq]
    if backend == "openrouter":
        return [openrouter]
    # Reached when `backend` doesn't match any case above -- e.g. the
    # frontend falls back to sending the literal string "default" whenever
    # #modelSelector isn't found in the DOM (frontend/static/js/index.js).
    # This used to stop at Groq and never reach OpenRouter, unlike the
    # "auto" chain just above it.
    return [g25_flash, deepseek, groq, openrouter]


def _context_already_has_search(context: str) -> bool:
    markers = (
        "[WEB SEARCH RESULTS]",
        "[REAL-TIME LIVE DATA FROM WEB]",
        "[DEDICATED WEB SEARCH RESULTS]",
    )
    return any(m in (context or "") for m in markers)


def ask_ai(question: str, context: str = "", backend: str = "auto") -> str:
    """
    Call the best available language model.

    Routing (files / YouTube / primary search / greetings) belongs in routes/chat.py.
    This function only:
      1. Rejects empty input
      2. Optionally enriches empty context with a last-resort search for live facts
      3. Failovers across providers
    """
    if not question or len(question.strip()) < 1:
        return "Please provide a valid question."

    q = question.strip()
    logger.info("=" * 50)
    logger.info(f"AI Request: {q[:80]}...")
    logger.info(f"Backend: {backend} | Context chars: {len(context or '')}")
    logger.info("=" * 50)

    # Narrow ambiguity guard — only pure pronouns / "help"
    if is_ambiguous(q) and not (context or "").strip():
        logger.info("Ambiguous prompt with empty context — asking for clarification")
        return "Could you please clarify what you mean? I want to give you the most accurate answer."

    # Last-resort search ONLY when chat did not already inject results
    # and the question clearly needs current data.
    if is_uncertain(q) and not _context_already_has_search(context or ""):
        try:
            from services.search import search_web

            logger.info(f"Last-resort web search for: {q[:60]}")
            search_results = search_web(q, max_results=5, use_cache=True)
            if search_results and not search_results.startswith("[No search"):
                context = (context or "") + f"\n\n[WEB SEARCH RESULTS]\n{search_results}"
        except Exception as e:
            logger.warning(f"Last-resort search failed: {e}")

    providers = _build_provider_chain(backend)
    errors: List[str] = []

    for provider_name, provider_func in providers:
        try:
            result = provider_func(q, context or "")
            if result and len(result) > 10 and not result.startswith("[Error"):
                logger.info(f"✅ Success: {provider_name} ({len(result)} chars)")
                # Optional refine if response is vague and we have no search yet
                if is_vague(result) and not _context_already_has_search(context or ""):
                    try:
                        from services.search import search_web

                        extra = search_web(q, max_results=5, use_cache=True)
                        if extra and not extra.startswith("[No search"):
                            refined = provider_func(
                                q,
                                (context or "") + f"\n\n[WEB SEARCH RESULTS]\n{extra}",
                            )
                            if refined and len(refined) > 10 and not is_vague(refined):
                                return refined
                    except Exception as e:
                        logger.debug(f"Vague-response refine failed: {e}")
                return result
            errors.append(f"{provider_name}: empty/invalid response")
        except Exception as e:
            errors.append(f"{provider_name}: {str(e)[:80]}")
            logger.warning(f"Provider {provider_name} raised: {e}")
            continue

    error_summary = "All AI models unavailable."
    if errors:
        error_summary += f" Last errors: {', '.join(errors[:3])}"
    logger.error(error_summary)
    return (
        f"[Error: {error_summary} "
        "Please check your API keys and internet connection.]"
    )


# ==========================================================
# UTILITIES / EXPORTS
# ==========================================================
async def generate_image_gemini(prompt: str, model_id: str = "gemini-2.5-flash-image") -> Dict[str, Any]:
    if not GEMINI_AVAILABLE or not GOOGLE_API_KEY:
        return {"success": False, "error": "Gemini not available"}
    try:
        import base64
        import google.genai as genai

        client = genai.Client(api_key=GOOGLE_API_KEY)
        response = client.models.generate_content(
            model=model_id,
            contents=f"Generate a professional educational diagram: {prompt}.",
        )
        if response.candidates and response.candidates[0].content:
            for part in response.candidates[0].content.parts:
                if hasattr(part, "inline_data") and part.inline_data:
                    image_base64 = base64.b64encode(part.inline_data.data).decode("utf-8")
                    if len(image_base64) > 1000:
                        return {
                            "success": True,
                            "image_data": image_base64,
                            "provider": f"Gemini ({model_id})",
                        }
        return {"success": False, "error": "No image in response"}
    except Exception as e:
        logger.warning(f"Gemini image gen failed: {e}")
        return {"success": False, "error": "Image generation failed"}


def list_available_models() -> List[Dict[str, Any]]:
    models: List[Dict[str, Any]] = []
    if GEMINI_AVAILABLE:
        for model_id, info in GEMINI_MODELS.items():
            models.append(
                {
                    "provider": "Gemini",
                    "model_id": model_id,
                    "name": info["name"],
                    "context_limit": info["tokens"],
                    "priority": info["priority"],
                }
            )
    if DEEPSEEK_AVAILABLE:
        models.append(
            {
                "provider": "DeepSeek",
                "model_id": "deepseek-chat",
                "name": "DeepSeek V3",
                "context_limit": 64000,
                "priority": 10,
            }
        )
    if GROQ_AVAILABLE:
        models.append(
            {
                "provider": "Groq",
                "model_id": "llama-3.3-70b-versatile",
                "name": "Llama 3.3 70B",
                "context_limit": 131072,
                "priority": 20,
            }
        )
    if OPENROUTER_AVAILABLE:
        for model in OPENROUTER_MODELS:
            models.append(
                {
                    "provider": "OpenRouter",
                    "model_id": model["id"],
                    "name": model["name"],
                    "context_limit": model["tokens"],
                    "priority": 30,
                }
            )
    return sorted(models, key=lambda x: x.get("priority", 999))


def test_provider(provider: str) -> Dict[str, Any]:
    test_query = "Say 'Hello' and nothing else."
    if provider == "gemini":
        result = ask_gemini(test_query, "", "gemini-2.5-flash")
    elif provider == "deepseek":
        result = ask_deepseek(test_query)
    elif provider == "groq":
        result = ask_groq(test_query)
    elif provider == "openrouter":
        result = ask_openrouter(test_query)
    else:
        return {"success": False, "error": f"Unknown provider: {provider}"}
    if result:
        return {"success": True, "response": result}
    return {"success": False, "error": "Provider returned no response"}


__all__ = [
    "ask_ai",
    "ask_gemini",
    "ask_deepseek",
    "ask_groq",
    "ask_openrouter",
    "detect_subject",
    "detect_intent",
    "is_greeting",
    "is_ambiguous",
    "is_uncertain",
    "list_available_models",
    "test_provider",
    "generate_image_gemini",
    "GEMINI_AVAILABLE",
    "GROQ_AVAILABLE",
]

logger.info("👁️ Vision AI Provider Router v2.0 - Ready")
